const UserText1 = localStorage.getItem("1");
// <yes> <report> JS_XSS_PERSISTENT react01
var Hello = <div dangerouslySetInnerHTML={{ __html: UserText1}}></div>;

class AboutUserComponent extends React.Component {
    render() {
        const UserText2 = localStorage.getItem("1");
        return (
            // <yes> <report> JS_XSS_PERSISTENT react01
            <div dangerouslySetInnerHTML={{"__html": UserText2}} />
        );
    }
}

// +DATABASE to return
const state = store.getState();
const inlineScript = `
    <script>
        <!-- // <yes> <report> JS_XSS_PERSISTENT react04 -->
        window.__INITIAL_DATA__ = ${JSON.stringify(state)};
    </script>
    `

function renderFullPage(html, preloadedState) {
    return `
        <!doctype html>
        <html>
            <head>
                <title>Redux Universal Example</title>
            </head>
            <body>
                <script>
                    <!-- // <yes> <report> JS_XSS_PERSISTENT react04 -->
                    window.__PRELOADED_STATE__ = ${JSON.stringify(store.getState())}
                </script>
                <script src="/static/bundle.js"></script>
            </body>
        </html>
        `
}

class UserProfilePage extends React.Component {
    render() {
        const userWebsite = localStorage.getItem("site");
        // <yes> <report> JS_XSS_PERSISTENT react06
        return (<a href={userWebsite}>My Website</a>)
    }
}
const input = localStorage.getItem("site");
// <yes> <report> JS_XSS_PERSISTENT react06
let zzz = <Foo className={"foobar"} href={input} />;
// <yes> <report> JS_XSS_PERSISTENT react06
const e = await render(<form action={input}>p0wned</form>, 1);

function style1() {
    const input = localStorage.getItem("style");
    return (
            <!-- // <yes> <report> JS_XSS_PERSISTENT react08 -->
            <div style={input}>
                Hello world
            </div>
    );
}

function  style2() {
    const input = localStorage.getItem("style");
    return (
            <!-- // <no> <report> -->
            <div style={{color: input}}>
                Hello world
            </div>
    );
}

let userPreferences = JSON.parse(localStorage.getItem("data"));
// <yes> <report> JS_XSS_PERSISTENT react12
React.createElement('span', userPreferences);

class HtmlComponent extends React.Component {
    render() {
        // <yes> <report> JS_XSS_PERSISTENT react16
        var dev = ReactHtmlParser(localStorage.getItem("html"));
        const html = localStorage.getItem("html");
        return (
            <div>
                <!-- // <yes> <report> JS_XSS_PERSISTENT react16 -->
                { ReactHtmlParser(html) }
            </div>
        );
  }
}

