let foo = function() {
    try {
        return 1;
    } catch(err) {
        return 2;
// <yes> <report> JS_CORRECTNESS_USE_FINALLY srtq02
    } finally {
        return 3;
    }
};

let foo = function() {
    try {
        return 1;
    } catch(err) {
        return 2;
// <yes> <report> JS_CORRECTNESS_USE_FINALLY srtq02
    } finally {
        throw new Error;
    }
};

let foo = function() {
    try {
        return 1;
    } catch(err) {
        return 2;
    } finally {
        let a = function() {
            return "hola!";
        }
    }
};

let foo = function() {
    try {
        return 1;
    } catch(err) {
        return 2;
    } finally {
        console.log("hola!");
    }
};

let foo = function(a) {
    try {
        return 1;
    } catch(err) {
        return 2;
    } finally {
        switch(a) {
            case 1: {
                console.log("hola!")
                break;
            }
        }
    }
};