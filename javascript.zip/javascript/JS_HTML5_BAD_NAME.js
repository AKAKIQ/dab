// <yes> <report> JS_HTML5_BAD_NAME 0bc948
var db = openDatabase('mydb', '1.0', 'Test DB', 2 * 1024 * 1024);