// <no> <report>
typeof foo === "string"
// <yes> <report> JS_POSSIBLE_TYPO srtq03
typeof foo == "undefimed"
// <yes> <report> JS_POSSIBLE_TYPO srtq03
typeof bar = "mumber"
// <yes> <report> JS_POSSIBLE_TYPO srtq03
typeof bar !== "fucntion"