const val = window.location;
// <yes> <report> JS_LOGGING_LOG_FORGING r11qe1
console.error("INFO: Failed to parse val = " + val);
// <yes> <report> JS_LOGGING_LOG_FORGING r11qe1
console.log(this.$el.textContent);
// <yes> <report> JS_LOGGING_LOG_FORGING r11qe1
console.log(vm.$el.textContent);
