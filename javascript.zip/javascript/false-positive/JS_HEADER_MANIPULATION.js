document.referrer = 'smth';

