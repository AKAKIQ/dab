// <yes> <report> JS_CORRECTNESS_CONTROL_CHARACTERS sdbd35
var pattern1 = /\x1f/;
// <yes> <report> JS_CORRECTNESS_CONTROL_CHARACTERS sdbd34
var pattern2 = new RegExp("\x1f");