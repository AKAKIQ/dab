function db1(rows) {
// <yes> <report> JS_OPEN_REDIRECT bc82ab
    location.assign(rows);
// <yes> <report> JS_OPEN_REDIRECT af2351
    window.open(rows);
// <yes> <report> JS_OPEN_REDIRECT a75847
    history.current = rows;
// <yes> <report> JS_OPEN_REDIRECT fd84df
    history.go(rows);
// <yes> <report> JS_OPEN_REDIRECT 84f93a
    document.URL = rows;
// <yes> <report> JS_OPEN_REDIRECT adf764
    window.location = rows;
// <yes> <report> JS_OPEN_REDIRECT b912dc
    smth.location.assign(rows);
// <yes> <report> JS_OPEN_REDIRECT 4e4d60
    smth.window.open(rows);
// <yes> <report> JS_OPEN_REDIRECT c2df2a
    smth.history.current = rows;
// <yes> <report> JS_OPEN_REDIRECT 9c2494
    smth.history.go(rows);
// <no> <report>
    smth.document.URL = rows;
// <yes> <report> JS_OPEN_REDIRECT 094ace
    smth.window.location = rows;
// <yes> <report> JS_OPEN_REDIRECT chfnmt
    smth.location.hash = rows;
// <yes> <report> JS_OPEN_REDIRECT b56cad
    location.hash = rows;
}

function db2(result) {
    const rows = result.rows;
// <yes> <report> JS_OPEN_REDIRECT bc82ab
    location.assign(rows);
// <yes> <report> JS_OPEN_REDIRECT af2351
    window.open(rows);
// <yes> <report> JS_OPEN_REDIRECT a75847
    history.current = rows;
// <yes> <report> JS_OPEN_REDIRECT fd84df
    history.go(rows);
// <yes> <report> JS_OPEN_REDIRECT 84f93a
    document.URL = rows;
// <yes> <report> JS_OPEN_REDIRECT adf764
    window.location = rows;
// <yes> <report> JS_OPEN_REDIRECT b912dc
    smth.location.assign(rows);
// <yes> <report> JS_OPEN_REDIRECT 4e4d60
    smth.window.open(rows);
// <yes> <report> JS_OPEN_REDIRECT c2df2a
    smth.history.current = rows;
// <yes> <report> JS_OPEN_REDIRECT 9c2494
    smth.history.go(rows);
// <no> <report>
    smth.document.URL = rows;
// <yes> <report> JS_OPEN_REDIRECT 094ace
    smth.window.location = rows;
// <yes> <report> JS_OPEN_REDIRECT 3979e2
    smth.document.location = rows;
}
// <yes> <report> JS_OPEN_REDIRECT bc82ab
location.assign(smth.window.location);
// <no> <report>
document.URL = '';
// <no> <report>
smth.document.URL = '';

const routes = [{ path: '/home',
    // <yes> <report> JS_OPEN_REDIRECT djswqk
    redirect: smth.window.location }]
// <no> <report>
const routesGood = [{ path: '/home', redirect: '/' }]
// <yes> <report> JS_OPEN_REDIRECT fkerwa
router.push({ path: `/user/${smth.window.location}` })
// <yes> <report> JS_OPEN_REDIRECT fkeeql
router.push({ path: smth.window.location })
// <yes> <report> JS_OPEN_REDIRECT fkeeql
router.push({ path: '/user/' + smth.window.location })
// <no> <report>
router.push({ path: `/user/` })

// +DOM_HREF to return
url = $( '.something' ).attr( 'href' );
// <yes> <report> JS_OPEN_REDIRECT bc82a1
location.assign(url);
// <yes> <report> JS_OPEN_REDIRECT af2311
window.open(url);
// <yes> <report> JS_OPEN_REDIRECT a75841
history.current = url;
// <yes> <report> JS_OPEN_REDIRECT fd84d1
history.go(url);
// <yes> <report> JS_OPEN_REDIRECT 84f931
document.URL = url;
// <yes> <report> JS_OPEN_REDIRECT adf761
window.location = url;
// <yes> <report> JS_OPEN_REDIRECT b912d1
smth.location.assign(url);
// <yes> <report> JS_OPEN_REDIRECT 4e4d61
smth.window.open(url);
// <yes> <report> JS_OPEN_REDIRECT c2df21
smth.history.current = url;
// <yes> <report> JS_OPEN_REDIRECT 9c2491
smth.history.go(url);
// <yes> <report> JS_OPEN_REDIRECT 3979e1
smth.document.location = url;
// <yes> <report> JS_OPEN_REDIRECT 094ac1
smth.window.location = url;
// <yes> <report> JS_OPEN_REDIRECT chfnm1
smth.location.hash = url;
// <yes> <report> JS_OPEN_REDIRECT b56ca1
location.hash = url;

const routes = [{ path: '/home',
    // <yes> <report> JS_OPEN_REDIRECT djswq1
    redirect: url}]
// <yes> <report> JS_OPEN_REDIRECT fkeeq1
router.push({ path: url })
// <yes> <report> JS_OPEN_REDIRECT fkerw1
router.push({ path: `/user/${url}` })