// <yes> <report> JS_COOKIE_BROAD_PATH 107084
document.cookie ='cookie1=test; path=/; expires=Fri, 3 Aug 2001 20:47:11 UTC; secure=true'
// <yes> <report> JS_COOKIE_BROAD_PATH 107083
document.cookie ='cookie1=test; expires=Fri, 3 Aug 2001 20:47:11 UTC; secure=true; path=/'
// <yes> <report> JS_COOKIE_BROAD_PATH 107085 <yes> <report> JS_COOKIE_NOT_OVER_SSL 405016 <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015 
res.cookie('name', 'tobi');
// <yes> <report> JS_COOKIE_BROAD_PATH 107085 <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('name', 'tobi', {domain: 'secure.example.com', secure: true });
// <yes> <report> JS_COOKIE_BROAD_PATH 107085 <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('name', 'tobi', { domain: 'secure.example.com', path: '/', secure: true });
// <no> <report>
res.cookie('name', 'tobi', { domain: 'secure.example.com', path: '/admin', secure: true, httpOnly: true });