var Tx = require('ethereumjs-tx').Transaction;
let privateKey;
privateKey = Buffer.from('e331b6d69882b4cb4ea581d88e0b604039a3de5967688d3dcffdd2270c0fd109', 'hex');
const mnemonic = "string with mnemonic";
let tx = new Tx();
userPassword = "mypass";

module.exports = {
    networks: {
        ropsten: {
            // <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA sdf3g5 <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
            provider: () => new HDWalletProvider('my mnemonic string', `https://ropsten.infura.io/api/v3/${apiKey}`),
        },
        kovan: {
            // <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA sdf3g5 <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
            provider: () => new HDWalletProvider(mnemonic, `https://ropsten.infura.io/v3/${apiKey}`),
        },
        mainnet: {
            // <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
            provider: () => new HDWalletProvider(process.env.MNEMONIC, `https://ropsten.infura.io/v3/${apiKey}`),
        },
        rinkeby: {
            // <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA sdf3g5 <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
            provider: () => new HDWalletProvider("my mnemonic string", `https://ropsten.infura.io/v3/${apiKey}`),
        },
    },
};

// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA d4hje4
web3.eth.accounts.sign(data, privateKey);
// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA d4hje4
web3.eth.accounts.signTransaction(tx, privateKey);

// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA lgh4h3
web3.shh.addPrivateKey(privateKey);
// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA df6fhk
web3.eth.accounts.privateKeyToAccount(privateKey);

// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA gf7js4
web3.eth.personal.sign(data, userAddress, userPassword);
// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA ljleh3
window.web3.eth.personal.signTransaction(tx, userPassword);
// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA ljleh3
web3.eth.personal.signTransaction(tx, userPassword);

// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA lgh4h3
web3.shh.addPrivateKey(privateKey);
// <yes> <report> JS_WEB3_HARDCODED_SENSITIVE_DATA lgh4h3
window.web3.shh.addPrivateKey(privateKey);


tx.sign(process.env.PRIVATE_KEY);
web3.eth.accounts.signTransaction(tx, process.env.PRIVATE_KEY);

web3.eth.accounts.privateKeyToAccount(process.env.PRIVATE_KEY);
web3.eth.accounts.sign(data, pk);
web3.shh.addPrivateKey(process.env.PRIVATE_KEY);

web3.eth.sign(dataToSign, addr);

let r = 25;

o = Math.abs(r) > someValue / 2 ? -Math.sign(r) * someValue : 0;

return u(this.getKey().sign(t, e, n));
