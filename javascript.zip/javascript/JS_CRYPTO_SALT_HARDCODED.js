// <yes> <report> JS_CRYPTO_SALT_HARDCODED lkr432
var key = CryptoJS.PBKDF2(pass, "hardcoded", { keySize: 128/32 }); 
// <yes> <report> JS_CRYPTO_SALT_HARDCODED lkk32w
var derivedKey = sjcl.misc.pbkdf2( password, "hardcoded", 100, 256, hmacSHA1 );
// <yes> <report> JS_CRYPTO_SALT_HARDCODED tekssm
var salt = "salt";
// <yes> <report> JS_CRYPTO_SALT_HARDCODED tkeles
crypto.pbkdf2(pass, 'salt', 100000, 64, 'sha512');