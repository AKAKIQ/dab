INFURA_KEY = "myinfurakey";


module.exports = {
    networks: {
        ropsten: {
            // <yes> <report> JS_WEB3_HARDCODED_API_KEY f6kj7g <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
            provider: () => new HDWalletProvider(mnemonic, `https://ropsten.infura.io/api/v3/myinfurakey`),
        },
        kovan: {
            // <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
            provider: () => new HDWalletProvider(mnemonic, `https://ropsten.infura.io/v3/`),
        },
        mainnet: {
            // <yes> <report> JS_WEB3_HARDCODED_API_KEY f6kj7g <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
            provider: () => new HDWalletProvider(mnemonic, 'https://ropsten.infura.io/v3/' + INFURA_KEY),
        },
        rinkeby: {
            // <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
            provider: () => new HDWalletProvider(mnemonic, `https://ropsten.infura.io/v3/${process.env.API_KEY}`),
        },
    },
};