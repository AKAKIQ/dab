var NodeRSA = require('node-rsa');
var key = new NodeRSA({b: 2048});
// <yes> <report> JS_CRYPTO_BAD_PADDING fgerje
key.setOptions({encryptionScheme: 'pkcs1'});
var constants = require("constants");
// <yes> <report> JS_CRYPTO_BAD_PADDING tgrjke
var encrypted = crypto.publicEncrypt({key:data, padding:constants.RSA_NO_PADDING}, bufferToEncrypt).toString("base64");