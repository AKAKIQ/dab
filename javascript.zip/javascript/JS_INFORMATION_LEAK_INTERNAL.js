// <yes> <report> JS_INFORMATION_LEAK_INTERNAL 22lk3e
$log.info( os.freemem() ); //log, warn, info, error, debug
