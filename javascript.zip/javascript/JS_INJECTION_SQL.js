executeSql(func(), [], nullDataHandler, errorHandler);
executeSql(null, [], nullDataHandler, errorHandler);
var user_input = '';
user_input = document.getElementById("el");
// <yes> <report> JS_INJECTION_SQL e969fe
executeSql(user_input, 'smth_else');

// <yes> <report> JS_INJECTION_SQL e969fe
executeSql(document.getElementById("el").src, 'smth_else');

(function () {
    var username = document.form.username.value;
    var itemName = document.form.itemName.value;
    var query = "SELECT * FROM items WHERE owner = " + username + " AND itemname = " + itemName + ";";
    db.transaction(function (tx) {
        // <yes> <report> JS_INJECTION_SQL e969fe
        tx.executeSql(query);
    })
})();

(function () {
    var username = window.document.form.username.value;
    var itemName = window.document.form.itemName.value;
    var query = "SELECT * FROM items WHERE owner = " + username + " AND itemname = " + itemName + ";";
    db.transaction(function (tx) {
        // <yes> <report> JS_INJECTION_SQL e969fe
        tx.executeSql(query);
    })
})();

// That's a FP here because of
// https://gitlab.smartdec.ru/ast/appscreener/core/incode-match-check/issues/286 and most likely
// of some rules in passthrough
// (function () {
//     var username2 = window.document.defaultView;
//     var itemName2 = 'text';
//     var query2 = "SELECT * FROM items WHERE owner = " + username2 + " AND itemname = " + itemName2 + ";";
//     db.transaction(function (tx) {
//         // <no> <report>
//         tx.executeSql(query2);
//     })
// })();

function cassandra() {
    const cassandra = require('cassandra-driver');

    const client = new cassandra.Client({
        contactPoints: ['h1', 'h2'],
        localDataCenter: 'datacenter1',
        keyspace: 'ks1'
    });

    const query = `SELECT name, email FROM users WHERE key = ?`;
    // <no> <report>
    client.execute(query, [document.form.username])
        .then(result => {
            console.log('User with email %s', result.rows[0].email)
        });

    const badQuery = 'SELECT name, email FROM users WHERE key = ' + document.form.username;
    // <yes> <report> JS_INJECTION_SQL fjfkeo
    client.execute(badQuery, ['text'])
        .then(result => {
            console.log('User with email %s', result.rows[0].email)
        });
}

function mysql() {
    var mysql = require('mysql')
    var connection = mysql.createConnection({
        host: 'localhost',
        user: 'dbuser',
        // <yes> <report> JS_PASSWORD_HARDCODED 7cba87
        password: 's3kreee7',
        database: 'my_db'
    })

    connection.connect()
    // <yes> <report> JS_INJECTION_SQL fmgjek
    connection.query('SELECT 1 + 1 AS solution' + document.form.username, function (err, rows, fields) {
        if (err) throw err
        // <yes> <report> JS_LOGGING_LOG_FORGING r11qe1
        console.log('The solution is: ', rows[0].solution)
    })

    connection.end()
}

function oracle() {
    const oracledb = require('oracledb')
    const config = {
        connectString: 'localhost:1521/orcl'
    }

    async function getEmployee (empId) {
        let conn = conn = await oracledb.getConnection(config)
        // <yes> <report> JS_INJECTION_SQL fjfkeo
        const result = await conn.execute('select * from employees where employee_id = ' + document.form.username, [empId])
    }
}

function postgreSQL() {
    var pgp = require('pg-promise')()
    var db = pgp('postgres://username:password@host:port/database')
    // <yes> <report> JS_INJECTION_SQL ngjrlw
    db.one('SELECT $1 AS value' + document.form.username, 123)
}