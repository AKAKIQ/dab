var file = fs.readFileSync(new URL('file://hostname/p/a/t/h/file'));

// <yes> <report> JS_INJECTION_COMMAND t967ke
oShell.ShellExecute(file.commandtoRun, commandParms, "", "open", "1");

// <yes> <report> JS_INJECTION_COMMAND t967ke
require('child_process').spawn(file);
// <yes> <report> JS_INJECTION_COMMAND t967ke
require('child_process').spawnSync(file);
// <yes> <report> JS_INJECTION_COMMAND t967ke
require('child_process').execFile(file);
// <yes> <report> JS_INJECTION_COMMAND t967ke
require('child_process').execFileSync(file);

var spawn = require('child_process').spawn;
// <yes> <report> JS_INJECTION_COMMAND td41fs
var bat = spawn(file.cmd, ['/c', 'my.bat']);
// <yes> <report> JS_INJECTION_COMMAND t967ke
var spawn_execution = executor.spawn(file.command, args);
execFile = require('child_process').execFile;
// <yes> <report> JS_INJECTION_COMMAND td41fs
child = execFile(file.node, ['--version']);
