var user_input = document.body.body;
// <yes> <report> JS_INJECTION_CODE afd813
eval(user_input);
// <yes> <report> JS_INJECTION_CODE afd812
importScripts(user_input);
// <yes> <report> JS_INJECTION_CODE a6d78f
window.setInterval(user_input);
// <yes> <report> JS_INJECTION_CODE b6d78f
window.eval(user_input);

// <yes> <report> JS_INJECTION_CODE 4d7103
WorkerGlobalScope.importScripts(user_input);