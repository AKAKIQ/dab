var user_input = window.location.hash;
// <yes> <report> JS_HEADER_MANIPULATION_COOKIES 7fa983
document.cookie = user_input;
// <yes> <report> JS_HEADER_MANIPULATION_COOKIES 041657
smth.document.cookie = user_input;

import Cookies = require("js-cookie");

// <yes> <report> JS_HEADER_MANIPULATION_COOKIES thmc00
Cookies.set('name', user_input);
// <no> <report>
Cookies.set('name', 'value');