// <yes> <report> JS_OBSOLETE 12fs5h
arguments.callee(n - 1);

// <yes> <report> JS_OBSOLETE lem65d
throw StopIteration;

// <yes> <report> JS_OBSOLETE lem64d
var iter = Iterator(a);
// <yes> <report> JS_OBSOLETE lsjen8
o.watch('p', function (id, oldval, newval) {
  return newval;
});
// <yes> <report> JS_OBSOLETE lsjen8
o.unwatch('p');
// <yes> <report> JS_OBSOLETE lem64d
escape('ć'); //unescape
// <yes> <report> JS_OBSOLETE kjrnsa
window.routeEvent(500, 0);
// <yes> <report> JS_OBSOLETE lsjen8
navigator.taintEnabled()
// <yes> <report> JS_OBSOLETE gdne45
document.domConfig
// <yes> <report> JS_OBSOLETE okjwnr
window.pkcs11.addModule(sMod, secPath, 0, 0);

fun1 :
function a( types, data, fn ) {
    break dsf;
// <yes> <report> JS_OBSOLETE obsbld
   return this.delegate( types, null, data, fn );
}