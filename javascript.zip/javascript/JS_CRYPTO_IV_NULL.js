// <yes> <report> JS_CRYPTO_IV_NULL trlesa
var iv = null;
// <yes> <report> JS_CRYPTO_IV_NULL ytlkem
crypto.createCipheriv("aes192", key, null);
// <yes> <report> JS_CRYPTO_IV_NULL rplye2
var decrypted = CryptoJS.AES.decrypt(encrypted, key, { iv: null });
// <yes> <report> JS_CRYPTO_IV_NULL wrt7e5
var r = Crypto.encrypts(message,key, null);