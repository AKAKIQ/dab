// <yes> <report> JS_CRYPTO_KEY_NULL 28afe0
var encryptionkey = null
// <yes> <report> JS_CRYPTO_KEY_NULL 28afe0
var mycryptkey = null;
// <yes> <report> JS_CRYPTO_KEY_NULL 28afe1
var publickey = null;

var crypto = require('crypto');
// <yes> <report> JS_CRYPTO_KEY_NULL aaaf5a
cipher = crypto.createCipher('aes-256-cbc', null);
// <yes> <report> JS_CRYPTO_KEY_NULL aaaf5a
decipher = crypto.createDecipheriv('aes-256-cbc', null, iv);

// <yes> <report> JS_CRYPTO_KEY_NULL had421
sjcl.encrypt(null, data);
// <yes> <report> JS_CRYPTO_KEY_NULL had421
sjcl.decrypt(null, data);

// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
encrypt(algorithm, null, data);
// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
decrypt(algorithm, null, data);
// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
sign(algorithm, null, data);
// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
verify(algorithm,null, signature, data);
// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
deriveKey(algorithm, null, derivedKeyType, extractable, keyUsages);
// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
deriveBits(algorithm, null, length);
// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
importKey(format, null, algorithm, extractable, keyUsages);
// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
exportKey(format, null);
// <yes> <report> JS_CRYPTO_KEY_NULL wslf4g
wrapKey(format, null, wrappingKey, wrapAlgorithm);
// <yes> <report> JS_CRYPTO_KEY_NULL saqc11
var encrypted = CryptoJS.AES.encrypt(string, null);
// <yes> <report> JS_CRYPTO_KEY_NULL sdl9jw
var key = CryptoJS.PBKDF2(null, salt, { keySize: 128/32 }); 
// <yes> <report> JS_CRYPTO_KEY_NULL sdl9jw
var derivedKey = sjcl.misc.pbkdf2(null, salt, 100, 256, hmacSHA1 );
// <yes> <report> JS_CRYPTO_KEY_NULL rgk3ww
var SamsRSAkey = cryptico.generateRSAKey(null, 2048);
// <yes> <report> JS_CRYPTO_KEY_NULL ttt788 
var r = Crypto.encrypts(message, null, iv);

