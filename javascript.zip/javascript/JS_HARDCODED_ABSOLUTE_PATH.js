// <yes> <report> JS_HARDCODED_ABSOLUTE_PATH spel14
const src = 'C:\\path\\to\\node_modules';
// <yes> <report> JS_HARDCODED_ABSOLUTE_PATH spel14
const src = "C:\\path\\to\\node_modules";