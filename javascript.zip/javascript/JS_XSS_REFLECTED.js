var user_input = req.params;
// <yes> <report> JS_XSS_REFLECTED nghfjr
document.writeln(user_input);
// <yes> <report> JS_XSS_REFLECTED ngyrld
style.background = user_input;
// <yes> <report> JS_XSS_REFLECTED 1jgn65
jQuery.after(user_input);
// <yes> <report> JS_XSS_REFLECTED 1jgn65
$.append(user_input);
// <yes> <report> JS_XSS_REFLECTED xjfrem
smth.document.writeln(user_input);
// <yes> <report> JS_XSS_REFLECTED 4jdu65
smth.style.background = user_input;
// <yes> <report> JS_XSS_REFLECTED fhdy54
smth.jQuery.after(user_input);
// <yes> <report> JS_XSS_REFLECTED fhdy54
smth.$.append(user_input);
// <yes> <report> JS_XSS_REFLECTED 1jgn65
$(".container").append(user_input);
$(document.createElement('div'))
          .addClass('dropdown-backdrop')
          // <no> <report> JS_XSS_REFLECTED 1jgn65
          .insertAfter($(this))
          .on('click', clearMenus)
//<yes> <report> JS_XSS_REFLECTED fm678a
user_input.insertAfter($(this))

var url = req.params[1];

if (a == 2) {
    // <yes> <report> JS_XSS_REFLECTED ugjt75
    smth.innerHTML = url;
    // <yes> <report> JS_XSS_REFLECTED ugjt75
    smth.insertAdjacentHTML = url;
}
// <yes> <report> JS_XSS_REFLECTED xnah54
document.getElementById('eRunningFrame').src = url;
// <no> <report>
document.getElementById('eRunningFrame');
// <no> <report>
document.getElementById('eRunningFrame').src = 'src';
// <yes> <report> JS_XSS_REFLECTED xnah54
document.getElementById('eRunningFrame').innerHTML = url;
// <yes> <report> JS_XSS_REFLECTED xnah54
document.getElementById('eRunningFrame').insertAdjacentHTML = url;
// <yes> <report> JS_XSS_REFLECTED ugjt75
smth.innerHTML = url;

const data = req.params.el;
// <yes> <report> JS_XSS_REFLECTED ugjt75
el.innerHTML = data;

var app = require('express')();

app.get('/user/:id', function(req, res) {
    // <yes> <report> JS_XSS_REFLECTED gjfn65
    res.send("Unknown user: " + req.params.id);
});

var app7 = new Vue({
    el: '#app-7',
    data: {
        groceryList: [
            // <yes> <report> JS_XSS_REFLECTED kfiewk
            { id: 0, text: data },
            { id: 1, text: 'Cheese' },
        ]
    }
})

new Vue({
    el: '#app',
    data: {
        // <yes> <report> JS_XSS_REFLECTED kfiewk
        message: data
    }
})

new Vue({
    el: '#app',
    // <yes> <report> JS_XSS_REFLECTED kfse32
    data: data
})

// <yes> <report> JS_XSS_REFLECTED fjkekq
createElement('span', data)

Vue.directive('demo', {
    update: function () {
        this.el.innerHTML =
            // <yes> <report> JS_XSS_REFLECTED ugjt75
            'name - ' + data + '<br>'
    }
})

const vueParam = $route.params.something;
const vueParamThis = this.$route.params.something;

new Vue({
    el: '#app',
    data: {
        // <yes> <report> JS_XSS_REFLECTED kfiewk
        message: vueParam
    }
})

new Vue({
    el: '#app',
    data: {
        // <yes> <report> JS_XSS_REFLECTED kfiewk
        message: vueParamThis
    }
})

// below tests for the framework Bootstrap
$('#example-tooltip').tooltip({
    // <yes> <report> JS_XSS_REFLECTED btstr1
    title: user_input,
    // <yes> <report> JS_XSS_REFLECTED btstr1
    template: user_input,
    trigger: 'hover',
    placement: 'bottom'
})

$(function () {
  $('.example-popover').popover({
    container: 'body',
    // <yes> <report> JS_XSS_REFLECTED btstr1
    content: user_input,
    // <yes> <report> JS_XSS_REFLECTED btstr1
    title: user_input,
    // <yes> <report> JS_XSS_REFLECTED btstr1
    template: user_input
  })
})

// +WEB to return
var urlopener = window.opener;
// <yes> <report> JS_XSS_REFLECTED xnah54
document.getElementById('eRunningFrame').src = urlopener;