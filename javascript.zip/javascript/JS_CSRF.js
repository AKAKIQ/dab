var req = new XMLHttpRequest();
// <yes> <report> JS_CSRF ed0544
req.open("POST", "/new_user", true);
// <yes> <report> JS_CSRF ff778b <yes> <report> JS_HIJACKING_AJAX dca283
v.method = 'get';
// <yes> <report> JS_HIJACKING_AJAX 3ff6ff <yes> <report> JS_CSRF 7fc074
jQuery.getJSON();