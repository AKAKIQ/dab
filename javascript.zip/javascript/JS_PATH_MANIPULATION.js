const user_input = document.getElementById("el");
// <yes> <report> JS_PATH_MANIPULATION fa4567
smth.getDirectory(user_input);
// <yes> <report> JS_PATH_MANIPULATION 5678ab
smth.moveTo('smth', user_input);

// <yes> <report> JS_PATH_MANIPULATION fa4567
fs.readdir(user_input,function(err,items){});
// <yes> <report> JS_PATH_MANIPULATION fa4567
reader.readAsText(user_input);