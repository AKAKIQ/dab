// <yes> <report> JS_CRYPTO_BAD_ITERATION_COUNT rtjrek
crypto.pbkdf2(password, salt, 50000, 64, 'sha512');