// <yes> <report> JS_CRYPTO_KEY_HARDCODED 21afe0
var cryptokey = 'hardcoded'
// <yes> <report> JS_CRYPTO_KEY_HARDCODED 21afe0
var mycryptokey = 'hardcoded'
// <yes> <report> JS_CRYPTO_KEY_HARDCODED z78df4
var publickey = 'mykey';

var crypto = require('crypto');
// <yes> <report> JS_CRYPTO_KEY_HARDCODED 7aaf5a
cipher = crypto.createCipher('aes-256-cbc', 'hardcoded');
// <no> <report>
decipher = crypto.createDecipher('aes-256-cbc', mykey);

// <yes> <report> JS_CRYPTO_KEY_HARDCODED radf9a
sjcl.encrypt("password", data);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED radf9a
sjcl.decrypt("password", data);

// <yes> <report> JS_CRYPTO_KEY_HARDCODED sabf1a
encrypt(algorithm, "key", data);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED sabf1a
decrypt(algorithm, "key", data);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED sabf1a
sign(algorithm, "key", data);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED sabf1a
deriveKey(algorithm, "baseKey", derivedKeyType, extractable, keyUsages);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED sabf1a
deriveBits(algorithm, "baseKey", length);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED sabf1a
importKey(format, "keyData", algorithm, extractable, keyUsages);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED sabf1a
exportKey(format, "key");
// <yes> <report> JS_CRYPTO_KEY_HARDCODED sabf1a
wrapKey(format, "key", wrappingKey, wrapAlgorithm);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED dadc92
var encrypted = CryptoJS.AES.encrypt(string, "password");
// <yes> <report> JS_CRYPTO_KEY_HARDCODED kdl9jw
var key = CryptoJS.PBKDF2("pass", salt, { keySize: 128/32 }); 
// <yes> <report> JS_CRYPTO_KEY_HARDCODED kdl9jw
var derivedKey = sjcl.misc.pbkdf2("password", salt, 100, 256, hmacSHA1);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED 8tek3w
var SamsRSAkey = cryptico.generateRSAKey("PassPhrase", 2048);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED kdl9jw
crypto.pbkdf2('secret', salt, 100000, 64, 'sha512');
// <yes> <report> JS_CRYPTO_KEY_HARDCODED npf789
var r = Crypto.encrypts(message,"key", iv);
// <yes> <report> JS_CRYPTO_KEY_HARDCODED dadc92
var result = crypto.subtle.encrypt(algorithm, "key", data);
// <no> <report>
return (v.verify(parsedSignature.params.signature, 'base64')); // hardcoded
// <no> <report>
var emitKey = false;
// <no> <report>
var isJsonldKeyword = /^@(context|id|value|language|type|container|list|set|reverse|index|base|vocab|graph)"/;
