'use strict';
// <yes> <report> JS_HTTP_USAGE d1fqe6
var http = require('http');
// <yes> <report> JS_HTTP_USAGE fmwlfw
http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.write('Hello World!');
  res.end();
}).listen(8080);

var net = require('net');
// <yes> <report> JS_HTTP_USAGE fmwlfw
var client = net.createConnection();

// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000 <yes> <report> JS_HTTP_USAGE jhu000
var url1 = "http://url.url";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> JS_HTTP_USAGE jhu0l0
var url2 = "http://localhost";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000 <yes> <report> JS_HTTP_USAGE jhu000
const url4 = "http://1.1.1.1";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> JS_HTTP_USAGE jhu0l0
let url5 = "http://localhost";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> JS_HTTP_USAGE jhu0l0
const url6 = "http://localhost";
// <not> <report>
parser.addSchema('http://good.com/Schema', schema, () => {});
// <yes> <report> JS_HTTP_USAGE jhu001 <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
maker.baker('http://good.com/Schema', schema, () => {});
// <yes> <report> JS_HTTP_USAGE jhu0l1 <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne003
maker.baker('http://127.0.0.1', schema, () => {});

// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002 <yes> <report> JS_HTTP_USAGE jhu001
cl("http://1.1.1.1");
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002 <yes> <report> JS_HTTP_USAGE jhu001
cl.lc("http://1.1.1.1");
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
parser("http://url.r");

let vafd = () => {
    // <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002 <yes> <report> JS_HTTP_USAGE jhu001
    make("http://url.ru");
};