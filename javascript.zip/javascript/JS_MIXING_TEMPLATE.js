customInterpolationApp.config(function($interpolateProvider) {
	// <yes> <report> JS_MIXING_TEMPLATE 2ddfuu
    $interpolateProvider.startSymbol('//');
    // <yes> <report> JS_MIXING_TEMPLATE 2ddfuu
    $interpolateProvider.endSymbol('//');
  });