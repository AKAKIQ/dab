var myHeaders = new Headers();

// <yes> <report> JS_XSS_NO_PROTECTION d1fse1
myHeaders.append('X-XSS-Protection', 0);
// <yes> <report> JS_XSS_NO_PROTECTION d1fse1
myHeaders.set('X-XSS-Protection', 0);
// <yes> <report> JS_XSS_NO_PROTECTION a1tse9
myHeaders['X-XSS-Protection'] = 0;
// <yes> <report> JS_XSS_NO_PROTECTION t1twe1
var options ={'X-XSS-Protection': 0};