// <yes> <report> JS_CRYPTO_BAD_RANDOM d85f97
Math.random();