let inline =
    <!-- // <yes> <report> JS_CSRF react18 -->
    <form action="https://mail.com/send" method="POST">
        <input name="smth" value=""/>
        <textarea name="message">
        </textarea>
    </form>;