myModule.config(function($sceProvider){
	// <yes> <report> JS_ESCAPING_DISABLED rnn555
  	$sceProvider.enabled(false);
  	// <yes> <report> JS_ESCAPING_DISABLED rnn555
  	$sceProvider.enabled(0);
  	// <yes> <report> JS_ESCAPING_DISABLED rnn555
  	$sceProvider.enabled(null);
});