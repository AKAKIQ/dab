// <no> <report>
user = await AsyncStorage.setItem('userId', data.userId);
// <yes> <report> JS_REACT_INTERNAL_STORAGE jgtks4
userKey = await AsyncStorage.setItem('privatKey', data._key);
// <yes> <report> JS_REACT_INTERNAL_STORAGE jgtks4
password = await Asyncstorage.getItem('@Password');
// <yes> <report> JS_REACT_INTERNAL_STORAGE jgtks4
tokenKey = await AsyncStorage.setItem('userToken',JSON.stringify(tokenKey));
// <yes> <report> JS_REACT_INTERNAL_STORAGE jgtkk4
userKey = await AsyncStorage.setItem('publicKey', data);