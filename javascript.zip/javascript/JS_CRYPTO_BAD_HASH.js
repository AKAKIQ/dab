// <yes> <report> JS_CRYPTO_BAD_HASH cb7b6e
md5(v);
//CryptoJS library 
// <yes> <report> JS_CRYPTO_BAD_HASH 12ks6e
var hash = CryptoJS.MD5("Message"); //MD5, SHA1
// <yes> <report> JS_CRYPTO_BAD_HASH clks6e
var sha1= CryptoJS.algo.SHA1.create(); 
const crypto = require('crypto');
// <yes> <report> JS_CRYPTO_BAD_HASH gerkee
const hash = crypto.createHash('sha');
// <yes> <report> JS_CRYPTO_BAD_HASH gwwkff
var hash = crypto.subtle.digest('SHA-1', buffer);
// <yes> <report> JS_CRYPTO_BAD_HASH cb7b6e
a = md5_ff(a, b, c, d, x[i+ 0], 7 , -680876936);

var o = {
    // <no> <report>
    weekdaysMin: 'Ya_Du_Se_Cho_Pa_Ju_Sha'.split('_')
};

import * as crypto from "crypto";
// <yes><report> JS_CRYPTO_BAD_HASH 404x02
import {Md5} from 'ts-md5/dist/md5';
// <yes><report> JS_CRYPTO_BAD_HASH gerkee
export const md5 = (contents: string) => createHash('md5').update(contents).digest("hex");
// <yes><report> JS_CRYPTO_BAD_HASH gerkee
var l = crypto.createHash('sha1').update("adewinf3").digest("hex");