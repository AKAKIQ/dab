function test1() {
    var user_input = document.body.body;
// <yes> <report> JS_INJECTION_RESOURCE 4571da
    URL.createObjectURL(user_input);
// <yes> <report> JS_INJECTION_RESOURCE 50fa12
    document.loadBindingDocument(user_input);
// <yes> <report> JS_INJECTION_RESOURCE 3a5f6d
    document.addBinding('smth', user_input);
// <yes> <report> JS_INJECTION_RESOURCE adf071
    smth.resolveLocalFileSystemSyncURI(user_input);
// <yes> <report> JS_INJECTION_RESOURCE 8c5d84
    smth.URL.createObjectURL(user_input);
// <yes> <report> JS_INJECTION_RESOURCE a810f8
    smth.document.loadBindingDocument(user_input);
// <yes> <report> JS_INJECTION_RESOURCE 852262
    smth.document.addBinding('smth', user_input);
// <no> <report>
    var socket = new WebSocket("ws://javascript.ru/ws");
// <yes> <report> JS_INJECTION_RESOURCE ret262
    var socket = new WebSocket(user_input);

// <no> <report>
    URL.createObjectURL('a');

}

function test2() {
    var user_input = 'text';
// <no> <report> JS_INJECTION_RESOURCE 4571da
    URL.createObjectURL(user_input);
// <no> <report> JS_INJECTION_RESOURCE 50fa12
    document.loadBindingDocument(user_input);
// <no> <report> JS_INJECTION_RESOURCE 3a5f6d
    document.addBinding('smth', user_input);
// <no> <report> JS_INJECTION_RESOURCE adf071
    smth.resolveLocalFileSystemSyncURI(user_input);
// <no> <report> JS_INJECTION_RESOURCE 8c5d84
    smth.URL.createObjectURL(user_input);
// <no> <report> JS_INJECTION_RESOURCE a810f8
    smth.document.loadBindingDocument(user_input);
// <no> <report> JS_INJECTION_RESOURCE 852262
    smth.document.addBinding('smth', user_input);
// <no> <report>
    var socket = new WebSocket("ws://javascript.ru/ws");
// <no> <report> JS_INJECTION_RESOURCE ret262
    var socket = new WebSocket(user_input);
}
