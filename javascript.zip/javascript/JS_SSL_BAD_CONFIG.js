var options = {
  key : fs.readFileSync('my-server-key.pem'),
  cert : fs.readFileSync('server-cert.pem'),
// <yes> <report> JS_SSL_BAD_CONFIG a1f2e1
  requestCert: false
};
// <yes> <report> JS_SSL_BAD_CONFIG wwfq44
tls.connect({
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
  host: 'https://www.hackersite.com',
  port: '443',
// <yes> <report> JS_SSL_BAD_CONFIG a1f2e1
  rejectUnauthorized: false
});

var https = require('https');

// <yes> <report> JS_SSL_BAD_CONFIG h1f1ej
https.globalAgent.options.secureProtocol = 'SSLv3_method';
// <yes> <report> JS_SSL_BAD_CONFIG h1f1ej
https.globalAgent.options.secureProtocol = 'SSLv23_method';
// <yes> <report> JS_SSL_BAD_CONFIG h1f1ej
https.globalAgent.options.secureProtocol = 'SSLv2_method';
// <yes> <report> JS_SSL_BAD_CONFIG d1fqe0
var options ={host: '192.168.1.85',port: 443,method: 'POST', secureProtocol:'SSLv2_method'};
// <yes> <report> JS_SSL_BAD_CONFIG grtgnk
var result = socket.renegotiate({
    requestCert: true
}, function(err){
            if (!err) {

                res.writeHead(200);
                res.end("Authenticated Hello World\n");
            } else {
                
            }
        });

var result = socket.s({
    // <yes> <report> JS_SSL_BAD_CONFIG a1f2e1
    requestCert: false
}, function(err){
    if (!err) {

        res.writeHead(200);
        res.end("Authenticated Hello World\n");
    } else {

    }
});
// <yes> <report> JS_SSL_BAD_CONFIG t1s1wj
https.globalAgent.options.requestCert = false;
