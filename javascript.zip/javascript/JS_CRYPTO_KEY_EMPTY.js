//<yes> <report> JS_CRYPTO_KEY_EMPTY 114fe0
var mycryptkey = ''
// <yes> <report> JS_CRYPTO_KEY_EMPTY 114fe0
var encryptionkey = ''
// <yes> <report> JS_CRYPTO_KEY_EMPTY 114fe1
var publickey = '';

var crypto = require('crypto');
// <yes> <report> JS_CRYPTO_KEY_EMPTY 7abf5a
cipher = crypto.createCipher('aes-256-cbc', '');
// <yes> <report> JS_CRYPTO_KEY_EMPTY 7abf5a
decipher = crypto.createDecipher('aes-256-cbc', '');

// <yes> <report> JS_CRYPTO_KEY_EMPTY tadh2a
sjcl.encrypt("", data);
// <yes> <report> JS_CRYPTO_KEY_EMPTY tadh2a
sjcl.decrypt("", data);

// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
encrypt(algorithm, "", data);
// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
decrypt(algorithm, "", data);
// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
sign(algorithm, "", data);
// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
verify(algorithm,"", signature, data);
// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
deriveKey(algorithm, "", derivedKeyType, extractable, keyUsages);
// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
deriveBits(algorithm, "", length);
// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
importKey(format, "", algorithm, extractable, keyUsages);
// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
exportKey(format, "");
// <yes> <report> JS_CRYPTO_KEY_EMPTY waqf4a
wrapKey(format, "", wrappingKey, wrapAlgorithm);
// <yes> <report> JS_CRYPTO_KEY_EMPTY paoc12
var encrypted = CryptoJS.AES.encrypt(string, "");
// <yes> <report> JS_CRYPTO_KEY_EMPTY ldl9jw
var key = CryptoJS.PBKDF2("", salt, { keySize: 128/32 }); 
// <yes> <report> JS_CRYPTO_KEY_EMPTY ldl9jw
var derivedKey = sjcl.misc.pbkdf2( "", salt, 100, 256, hmacSHA1);
// <yes> <report> JS_CRYPTO_KEY_EMPTY gtek3w
var SamsRSAkey = cryptico.generateRSAKey("", 2048);
// <no> <report>
var crypto_secretbox_KEYBYTES = 32;
// <no> <report>
let onDuplicateKeyUpdate = '';
