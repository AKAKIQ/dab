// <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('rememberme', '1', { path: '/admin', httpOnly: false , secure: true});
// <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('rememberme', '1', { path: '/admin', secure: true});
