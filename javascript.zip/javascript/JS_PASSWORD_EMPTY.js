// <yes> <report> JS_PASSWORD_EMPTY e5109d
var password_ = '';
// <yes> <report> JS_PASSWORD_EMPTY fac7a0
v.password_ = '';
// <yes> <report> JS_PASSWORD_EMPTY fac7a0
v['password_'] = '';

// <yes> <report> JS_PASSWORD_EMPTY cc2f57
var password = '';
// <yes> <report> JS_PASSWORD_EMPTY 6c99b0
v.password = '';
// <yes> <report> JS_PASSWORD_EMPTY 6c99b0
v['password'] = '';

obj = new XMLHttpRequest(); 
// <yes> <report> JS_HIJACKING_AJAX e21f94 <yes> <report> JS_PASSWORD_EMPTY 158b7c <yes> <report> JS_CSRF ed0544
obj.open('GET','/fetchusers.jsp?id='+form.id.value,'true','scott','');
var params = { 
	statics : {
			requestId : 0
		},
	config : {
			username : "admin",
			// <yes> <report> JS_PASSWORD_EMPTY 7cbf57
			password : "",
			// <yes> <report> JS_PASSWORD_EMPTY e5cd9d
			secondPassword : ""
		}
	};

var azure = require('azure-storage');
// <yes> <report> JS_PASSWORD_EMPTY vdbjes
var tableSvc = azure.createTableService(accountname, "");