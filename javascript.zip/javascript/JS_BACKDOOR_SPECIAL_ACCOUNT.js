// <yes> <report> JS_BACKDOOR_SPECIAL_ACCOUNT 4a7015 <yes> <report> JS_PASSWORD_HARDCODED 8a083f
if (password == "qwerty") 
	{ alert("hello") ; }
// <yes> <report> JS_BACKDOOR_SPECIAL_ACCOUNT 4a7015
if (password_new == "qwerty")
	{ alert("hello") ; }
// <no> <report>
if (password == true) 
	{ alert("hello") ; }
// <yes> <report> JS_BACKDOOR_SPECIAL_ACCOUNT 4b7015
if (hash == "8743b52063cd84097a65d1633f5c74f5") 
	{ alert("hello") ; }
// <no> <report>
if (loginNum == 123)
	{ alert("hello") ; }
// <no> <report>
if (password == "")
{ alert("hello") ; }