// <yes> <report> JS_CORRECTNESS_USE_GLOBAL_OBJECT srtq00
var math = Math();
// <yes> <report> JS_CORRECTNESS_USE_GLOBAL_OBJECT srtq00
var json = JSON();
// <yes> <report> JS_CORRECTNESS_USE_GLOBAL_OBJECT srtq00
var reflect = Reflect();

// <no> <report>
function area(r) {
    return Math.PI * r * r;
}
// <no> <report>
var object = JSON.parse("{}");
// <no> <report>
var value = Reflect.get({ x: 1, y: 2 }, "x");
// <yes> <report> JS_CORRECTNESS_USE_GLOBAL_OBJECT srtq01
var hasBarProperty = foo.hasOwnProperty("bar");
// <yes> <report> JS_CORRECTNESS_USE_GLOBAL_OBJECT srtq01
var isPrototypeOfBar = foo.isPrototypeOf(bar);
// <yes> <report> JS_CORRECTNESS_USE_GLOBAL_OBJECT srtq01
var barIsEnumerable = foo.propertyIsEnumerable("bar");
// <no> <report>
var hasBarProperty = Object.prototype.hasOwnProperty.call(foo, "bar");
// <no> <report>
var isPrototypeOfBar = Object.prototype.isPrototypeOf.call(foo, bar);
// <no> <report>
var barIsEnumerable = {}.propertyIsEnumerable.call(foo, "bar");
