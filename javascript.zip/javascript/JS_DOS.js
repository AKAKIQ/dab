// <yes> <report> JS_DOS 2fd49f
file.write();
var user_input = document.getElementsByClassName("el");
// <yes> <report> JS_DOS a58d32
requestFileSystem('smth', user_input);
// <yes> <report> JS_DOS rrd466
var encoded = encodeURI(fs.readSync(source, 'destination.txt'));
// <no> <report> JS_DOS rrd466
fs.renameSync(source, 'destination.txt');
// <yes> <report> JS_DOS rrd466
var encoded = encodeURI(fs.readSync(path, uid, gid));