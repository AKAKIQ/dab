function App() {
    destination = req.param("destination");
    return (
        <Route exact path="/">
            <!-- // <yes> <report> JS_OPEN_REDIRECT react03 -->
            {loggedIn ? <Redirect to={ destination } /> : <PublicHomePage />}
        </Route>
    );
}

function App1() {
// +DOM_HREF to return
url = $( '.something' ).attr( 'href' );
    return (
        <Route exact path="/">
            <!-- // <yes> <report> JS_OPEN_REDIRECT reacth3 -->
            {loggedIn ? <Redirect to={{
            pathname: { url },
            search: "?utm=your+face",
            state: { referrer: currentLocation }
            }} /> : <PublicHomePage />}
        </Route>
    );
}