var user_input = window.location;
// <yes> <report> JS_HEADER_MANIPULATION 183627
document.referrer = user_input;
// <yes> <report> JS_HEADER_MANIPULATION 127d00
smth.document.referrer = user_input;